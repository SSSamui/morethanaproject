// What the screen shows. The timer itself lives in PorkStore (shared with the
// widgets and Screen Time extensions); this keeps a copy for SwiftUI.

import SwiftUI
import WidgetKit

@MainActor
final class AppModel: ObservableObject {
    static let shared = AppModel()

    @Published private(set) var state = PorkStore.load()
    @Published var showHi = false
    @Published var showMorning = false
    @Published var funFirst = false     // the check-in opens with "something fun instead?"
    @Published var toast: String?
    @Published var releasingUntil = Date.distantPast // door animation after "let Pork out"

    private var toastTask: Task<Void, Never>?

    func send(_ cmd: PorkCommand) {
        if case .release = cmd { releasingUntil = Date().addingTimeInterval(3.2) }
        setState(PorkCommands.run(cmd))
    }

    func reload() {
        var s = PorkStore.load()
        s.advance()
        setState(s)
    }

    func becameActive() {
        let s = PorkCommands.run(.sync)
        PorkCommands.apply(s) // also catches up after changes made from the blocked-app screen
        #if !LITE
        ScreenTime.scheduleNight(s.settings)
        #endif
        setState(s)
        Task { await LiveActivities.update(s) }
        Alerts.requestPermission()
        Alerts.scheduleMorning()
        Nudges.recordUse()
        LockWatcher.shared.update(s)
        #if !LITE
        ScreenTime.scheduleMorning()
        ScreenTime.checkPromise()
        #endif
        checkMorning()
    }

    /// After 8 am with no promise yet: the morning screen comes first.
    func checkMorning() {
        if DayPlans.needsPromise(DayPlans.all()) {
            showHi = false
            showMorning = true
        }
    }

    /// Today's promise to Pork: play time and bedtime. Starts today's rules.
    func makePromise(minutes: Int, bedtime: Int) {
        let plan = DayPlan(day: DayPlans.dayKey(Date()), promiseMin: minutes, bedtime: bedtime, madeAt: Date())
        DayPlans.save(plan)
        SleepMode.end()
        updateSettings {
            $0.nightStart = bedtime   // after bedtime only focus apps, until morning
            $0.nightOn = true
        }
        Alerts.scheduleBedtime(plan)
        #if !LITE
        ScreenTime.startPromise(plan)
        #endif
    }

    /// "I'm going to sleep" / "I'm up": the sleep countdown on the screen
    /// and the Lock Screen.
    func goToSleep(_ on: Bool) {
        on ? SleepMode.start() : SleepMode.end()
        WidgetCenter.shared.reloadAllTimelines()
        let s = state
        Task { await LiveActivities.update(s) }
        objectWillChange.send()
    }

    func updateSettings(_ change: (inout PorkSettings) -> Void) {
        var st = state.settings
        change(&st)
        guard st != state.settings else { return }
        send(.settings(st))
    }

    func show(_ text: String) {
        toast = text
        toastTask?.cancel()
        toastTask = Task {
            try? await Task.sleep(nanoseconds: 4_000_000_000)
            if !Task.isCancelled { toast = nil }
        }
    }

    private func setState(_ s: PorkState) {
        LockWatcher.shared.update(s)
        let prev = state
        // Back to focus from the break: play the door animation.
        if (prev.phase == .break || prev.phase == .overtime) && s.phase == .focus {
            releasingUntil = max(releasingUntil, Date().addingTimeInterval(3.2))
        }
        if let r = s.lastReward, r != prev.lastReward, Date().timeIntervalSince(r.at) < 15 {
            show(s.phase == .break ? "Break time! Pork got \(r.items.joined()) 🐾" : "Pork got \(r.items.joined()) 🐾")
        }
        // New treats pop into the jar.
        withAnimation(.spring(response: 0.5, dampingFraction: 0.55)) {
            state = s
        }
    }
}
