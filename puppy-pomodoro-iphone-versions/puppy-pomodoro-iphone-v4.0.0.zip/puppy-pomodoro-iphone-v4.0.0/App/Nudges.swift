// Reminders while you're on distraction apps, run by Shortcuts automations
// (an iPhone app can't see which app you open by itself):
// - you open a distraction app → after 5 min a Pork reminder, after 10 min
//   your to-dos (both times can be changed in Settings);
// - you open a focus app → those reminders are cancelled;
// - an event in Calendar right now → Pork's check-in opens with it.
// Also counts how often you opened distraction apps today.

import Foundation
import Photos
import UIKit
import UserNotifications

enum Nudges {
    static let porkID = "pork.nudge.pork"
    static let notesID = "pork.nudge.notes"
    static let category = "pork.nudge"

    private static var defaults: UserDefaults { PorkStore.defaults }

    /// How many times you opened a distraction app today.
    static var opensToday: Int {
        defaults.string(forKey: "distractDay") == dayKey() ? defaults.integer(forKey: "distractOpens") : 0
    }

    /// How many times you opened a distraction app yesterday.
    static var opensYesterday: Int {
        let y = Calendar.current.date(byAdding: .day, value: -1, to: Date()) ?? Date()
        if defaults.string(forKey: "distractDay") == dayKey(y) { return defaults.integer(forKey: "distractOpens") }
        return defaults.string(forKey: "distractPrevDay") == dayKey(y) ? defaults.integer(forKey: "distractPrevOpens") : 0
    }

    /// Remembers that the phone was in use (for the sleep guess in the free
    /// version). Keeps the last 2 days.
    static func recordUse(_ now: Date = Date()) {
        var log = (defaults.array(forKey: "useLog") as? [Date]) ?? []
        if let last = log.last, now.timeIntervalSince(last) < 60 { return }
        log.append(now)
        log.removeAll { now.timeIntervalSince($0) > 48 * 3600 }
        defaults.set(log, forKey: "useLog")
    }

    /// Fell asleep / woke up, guessed from when apps were opened.
    static func sleepGuess(now: Date = Date()) -> (sleep: Date, wake: Date)? {
        let log = (defaults.array(forKey: "useLog") as? [Date]) ?? []
        let from = Calendar.current.startOfDay(for: now).addingTimeInterval(-6 * 3600) // yesterday 6 pm
        let marks = log.filter { $0 >= from && $0 <= now }.map { UseMark(start: $0, end: $0) }
        return SleepGuess.find(marks)
    }

    /// A distraction app was opened. Returns true when Pork's check-in should
    /// open right away: today's promise isn't made yet, or there's a calendar
    /// event now that wasn't shown yet.
    static func distractionOpened(now: Date = Date()) async -> Bool {
        let st = PorkStore.load().settings
        recordUse(now)
        // count it
        if defaults.string(forKey: "distractDay") != dayKey(now) {
            defaults.set(defaults.string(forKey: "distractDay"), forKey: "distractPrevDay")
            defaults.set(defaults.integer(forKey: "distractOpens"), forKey: "distractPrevOpens")
            defaults.set(dayKey(now), forKey: "distractDay")
            defaults.set(0, forKey: "distractOpens")
        }
        defaults.set(defaults.integer(forKey: "distractOpens") + 1, forKey: "distractOpens")
        if PorkPause.isOn { return false }   // ⏸ go wild for 30 minutes
        if DayPlans.needsPromise(DayPlans.all(), now: now) { return true }
        guard st.hiEnabled else { return false }

        // This pick-up: a new one after 20 quiet minutes.
        let newPickUp = !PickUp.isActive(now)
        if newPickUp { PickUp.begin(now) } else { PickUp.touch(now) }

        // Something from the "fun" list instead? Asked at most every 15 minutes,
        // so after "No thanks" you can go on.
        let askedAt = defaults.object(forKey: "funAskedAt") as? Date ?? .distantPast
        var askFun = false
        if now.timeIntervalSince(askedAt) > 15 * 60, !(await Todos.load(st, now: now)).fun.isEmpty {
            defaults.set(now, forKey: "funAskedAt")
            defaults.set(true, forKey: "funFirst")
            askFun = true
        }

        // Start the 5 / 10 minute reminders for a new pick-up. With Screen Time
        // (full version) they follow real minutes on distraction apps;
        // otherwise they're timed from now.
        if newPickUp {
            #if !LITE
            if ScreenTime.isOn {
                ScreenTime.startPickUp(now: now)
            } else {
                await schedule(st, from: now)
            }
            #else
            await schedule(st, from: now)
            #endif
        }

        // An event in Calendar now: show it once (again after 30 min).
        guard let event = Todos.currentEvent(now: now), !event.allDay else { return askFun }
        guard newPickUp || event.start > now else { return askFun }
        let shownTitle = defaults.string(forKey: "eventShown")
        let shownAt = defaults.object(forKey: "eventShownAt") as? Date ?? .distantPast
        if shownTitle == event.title && now.timeIntervalSince(shownAt) < 30 * 60 { return askFun }
        defaults.set(event.title, forKey: "eventShown")
        defaults.set(now, forKey: "eventShownAt")
        return true
    }

    /// True once after a distraction app was opened and Pork should offer the
    /// fun list first.
    static func takeFunFirst() -> Bool {
        let v = defaults.bool(forKey: "funFirst")
        defaults.set(false, forKey: "funFirst")
        return v
    }

    /// A focus app was opened: no reminders needed.
    static func focusOpened() {
        recordUse()
        PickUp.end()
        Alerts.cancelPaws()
        #if !LITE
        ScreenTime.endPickUp()
        #endif
        defaults.removeObject(forKey: "distractSince")
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: [porkID, notesID])
    }

    /// For the 12 am / 6 pm automations: true when to-dos are left, and Pork
    /// sends a reminder listing them.
    static func todosLeft(app: String?) async -> Bool {
        let st = PorkStore.load().settings
        let left = await Todos.unfinished(st)
        guard !left.isEmpty else { return false }
        let content = UNMutableNotificationContent()
        content.title = "Finish your to-dos 🐾" + (app.map { " · opening \($0)" } ?? "")
        content.body = bullets(left.map(\.title))
        content.sound = .default
        content.categoryIdentifier = category
        content.userInfo = ["open": "checkin"]
        try? await UNUserNotificationCenter.current().add(
            UNNotificationRequest(identifier: "pork.todosLeft", content: content, trigger: nil))
        return true
    }

    private static func schedule(_ st: PorkSettings, from now: Date) async {
        let center = UNUserNotificationCenter.current()
        center.removePendingNotificationRequests(withIdentifiers: [porkID, notesID])

        let pork = UNMutableNotificationContent()
        pork.title = "Pork is scratching the door 🐾"
        pork.body = "\(st.nudgeMin) minutes on distractions this time. Pork wants you back!"
        pork.sound = .default
        pork.categoryIdentifier = category
        pork.userInfo = ["open": "checkin"]
        if let picture = await porkPicture(st) { pork.attachments = [picture] }
        try? await center.add(UNNotificationRequest(
            identifier: porkID, content: pork,
            trigger: UNTimeIntervalNotificationTrigger(timeInterval: TimeInterval(st.nudgeMin * 60), repeats: false)))

        let todos = await Todos.load(st, now: now)
        let notes = UNMutableNotificationContent()
        notes.title = "\(st.notesMin) min on distractions · \(opensToday)× today 📝"
        notes.body = todos.preview.isEmpty
            ? "Tap to see your to-dos and screen time with Pork."
            : "To do:\n" + bullets(todos.preview)
        notes.sound = .default
        notes.categoryIdentifier = category
        notes.userInfo = ["open": "checkin"]
        try? await center.add(UNNotificationRequest(
            identifier: notesID, content: notes,
            trigger: UNTimeIntervalNotificationTrigger(timeInterval: TimeInterval(st.notesMin * 60), repeats: false)))
        if st.pawsOn { Alerts.paws(after: TimeInterval(st.notesMin * 60)) }
    }

    /// A random photo of Pork from the album (or his drawing) for the reminder.
    private static func porkPicture(_ st: PorkSettings) async -> UNNotificationAttachment? {
        final class Box { var image: UIImage? }
        let box = Box()
        let status = PHPhotoLibrary.authorizationStatus(for: .readWrite)
        if status == .authorized || status == .limited {
            let options = PHFetchOptions()
            options.predicate = NSPredicate(format: "title = %@", st.hiAlbum)
            if let album = PHAssetCollection.fetchAssetCollections(with: .album, subtype: .any, options: options).firstObject {
                let photoOptions = PHFetchOptions()
                photoOptions.predicate = NSPredicate(format: "mediaType = %d", PHAssetMediaType.image.rawValue)
                let assets = PHAsset.fetchAssets(in: album, options: photoOptions)
                if assets.count > 0 {
                    let asset = assets.object(at: Int.random(in: 0..<assets.count))
                    let request = PHImageRequestOptions()
                    request.isSynchronous = true
                    request.deliveryMode = .highQualityFormat
                    request.isNetworkAccessAllowed = true
                    PHImageManager.default().requestImage(for: asset, targetSize: CGSize(width: 900, height: 900),
                                                          contentMode: .aspectFit, options: request) { result, _ in
                        box.image = result
                    }
                }
            }
        }
        let image = box.image ?? UIImage(named: "PorkPace")
        guard let data = image?.jpegData(compressionQuality: 0.85) else { return nil }
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + ".jpg")
        guard (try? data.write(to: url)) != nil else { return nil }
        return try? UNNotificationAttachment(identifier: "pork", url: url)
    }

    private static func bullets(_ titles: [String]) -> String {
        titles.map { "• " + $0 }.joined(separator: "\n")
    }

    private static func dayKey(_ date: Date = Date()) -> String {
        let c = Calendar.current.dateComponents([.year, .month, .day], from: date)
        return "\(c.year ?? 0)-\(c.month ?? 0)-\(c.day ?? 0)"
    }
}
